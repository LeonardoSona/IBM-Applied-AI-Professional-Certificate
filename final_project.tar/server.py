"""
This module contains the Flask application for the Emotion Detector.
It analyzes text input for emotions and provides emotion analysis results.
"""
from flask import Flask, render_template, request

from EmotionDetection.emotion_detection import emotion_detector

app = Flask("Emotion Detector")

@app.route('/emotionDetector')
def emotion_detector_route():
    """
    Analyze the provided text for emotions and return the analysis results.

    Returns:
        str: The emotion analysis results in plain text.
    """
    # Get the text to analyze from the request
    text_to_analyze = request.args.get('textToAnalyze')

    # Call the emotion_detector function to get the emotion analysis result
    result = emotion_detector(text_to_analyze)

    # Check if the dominant emotion is None
    if result['dominant_emotion'] is None:
        response_message = "Invalid text! Please try again."
    else:
        # Create the response message
        response_message = (
            f"For the given statement, the system response is "
            f"'anger': {result['anger']:.9f}, 'disgust': {result['disgust']:.9f}, "
            f"'fear': {result['fear']:.9f}, 'joy': {result['joy']:.9f} and "
            f"'sadness': {result['sadness']:.9f}. The dominant emotion is "
            f"{result['dominant_emotion']}."
        )

    return response_message

@app.route("/")
def render_index_page():
    """
    Render the index.html page.

    Returns:
        str: The rendered HTML page.
    """
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='localhost', port=5000)
